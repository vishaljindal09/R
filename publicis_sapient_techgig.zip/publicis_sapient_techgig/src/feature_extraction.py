from copy import deepcopy
from functools import partial

import category_encoders as ce
import numpy as np
import pandas as pd
import cmath
from scipy.stats import kurtosis, iqr, skew
from sklearn.externals import joblib
from sklearn.linear_model import LinearRegression
from steppy.base import BaseTransformer
from steppy.utils import get_logger

from .utils import parallel_apply, safe_div, flatten_list

logger = get_logger()


class IDXMerge(BaseTransformer):
    def __init__(self, id_column, **kwargs):
        super().__init__()
        self.id_column = id_column

    def transform(self, table, features, categorical_features, **kwargs):
        merged_table = table.merge(features,
                                   left_on=self.id_column,
                                   right_on=self.id_column,
                                   how='left',
                                   validate='one_to_one')
        merged_table.drop(self.id_column, axis='columns', inplace=True)

        outputs = dict()
        outputs['features'] = merged_table
        outputs['feature_names'] = list(merged_table.columns)
        outputs['categorical_features'] = categorical_features
        return outputs


class FeatureJoiner(BaseTransformer):
    def __init__(self, id_column, use_nan_count=False, **kwargs):
        super().__init__()
        self.id_column = id_column
        self.use_nan_count = use_nan_count

    def transform(self, numerical_feature_list, categorical_feature_list, **kwargs):
        features = numerical_feature_list + categorical_feature_list
        for feature in features:
            feature.set_index(self.id_column, drop=True, inplace=True)
        features = pd.concat(features, axis=1).astype(np.float32).reset_index()
        if self.use_nan_count:
            features['nan_count'] = features.isnull().sum(axis=1)

        outputs = dict()
        outputs['features'] = features
        outputs['feature_names'] = list(features.columns)
        outputs['categorical_features'] = self._get_feature_names(categorical_feature_list)
        return outputs

    def _get_feature_names(self, dataframes):
        feature_names = []
        for dataframe in dataframes:
            try:
                feature_names.extend(list(dataframe.columns))
            except Exception as e:
                print(e)
                feature_names.append(dataframe.name)

        return feature_names


class FeatureConcat(BaseTransformer):
    def transform(self, features_list, feature_names_list, categorical_features_list, **kwargs):
        for feature in features_list:
            feature.reset_index(drop=True, inplace=True)

        outputs = dict()
        outputs['features'] = pd.concat(features_list, axis=1).astype(np.float32)
        outputs['feature_names'] = flatten_list(feature_names_list)
        outputs['categorical_features'] = flatten_list(categorical_features_list)
        return outputs


class CategoricalEncoder(BaseTransformer):
    def __init__(self, **kwargs):
        super().__init__()
        self.encoder_class = ce.OrdinalEncoder
        self.categorical_encoder = None

    def fit(self, X, categorical_columns, **kwargs):
        self.categorical_encoder = self.encoder_class(cols=categorical_columns, **kwargs)
        self.categorical_encoder.fit(X)
        return self

    def transform(self, X, **kwargs):
        X_ = self.categorical_encoder.transform(X)
        return {'categorical_features': X_}

    def load(self, filepath):
        self.categorical_encoder = joblib.load(filepath)
        return self

    def persist(self, filepath):
        joblib.dump(self.categorical_encoder, filepath)


class CategoricalEncodingWrapper(BaseTransformer):
    def __init__(self, encoder, **kwargs):
        super().__init__()
        self.encoder = encoder
        self.params = deepcopy(kwargs)

    def fit(self, X, y=None, cols=[], **kwargs):
        self.encoder = self.encoder(cols=cols, **self.params)
        self.encoder.fit(X, y)
        return self

    def transform(self, X, y=None, **kwargs):
        transformed = self.encoder.transform(X)
        return {'features': transformed,
                'feature_names': transformed.columns,
                'categorical_features': set(transformed.columns) - set(X.columns)}

    def persist(self, filepath):
        joblib.dump(self.encoder, filepath)

    def load(self, filepath):
        self.encoder = joblib.load(filepath)
        return self


class GroupbyAggregateDiffs(BaseTransformer):
    def __init__(self, id_column, groupby_aggregations, use_diffs_only=False, **kwargs):
        super().__init__()
        self.groupby_aggregations = groupby_aggregations
        self.use_diffs_only = use_diffs_only
        self.features = []
        self.groupby_feature_names = []
        self.id_column = id_column

    @property
    def feature_names(self):
        if self.use_diffs_only:
            return self.diff_feature_names
        else:
            return self.groupby_feature_names + self.diff_feature_names

    def fit(self, main_table, **kwargs):
        for groupby_cols, specs in self.groupby_aggregations:
            group_object = main_table.groupby(groupby_cols)
            for select, agg in specs:
                groupby_aggregate_name = self._create_colname_from_specs(groupby_cols, select, agg)
                group_features = group_object[select].agg(agg).reset_index() \
                    .rename(index=str,
                            columns={select: groupby_aggregate_name})[groupby_cols + [groupby_aggregate_name]]

                self.features.append((groupby_cols, group_features))
                self.groupby_feature_names.append(groupby_aggregate_name)
        return self

    def transform(self, main_table, **kwargs):
        main_table = self._merge_grouby_features(main_table)
        main_table = self._add_diff_features(main_table)

        return {'numerical_features': main_table[[self.id_column] + self.feature_names].astype(np.float32)}

    def _merge_grouby_features(self, main_table):
        for groupby_cols, groupby_features in self.features:
            main_table = main_table.merge(groupby_features,
                                          on=groupby_cols,
                                          how='left')
        return main_table

    def _add_diff_features(self, main_table):
        self.diff_feature_names = []
        for groupby_cols, specs in self.groupby_aggregations:
            for select, agg in specs:
                if agg in ['mean', 'median', 'max', 'min']:
                    groupby_aggregate_name = self._create_colname_from_specs(groupby_cols, select, agg)
                    diff_feature_name = '{}_diff'.format(groupby_aggregate_name)
                    abs_diff_feature_name = '{}_abs_diff'.format(groupby_aggregate_name)

                    main_table[diff_feature_name] = main_table[select] - main_table[groupby_aggregate_name]
                    main_table[abs_diff_feature_name] = np.abs(main_table[select] - main_table[groupby_aggregate_name])

                    self.diff_feature_names.append(diff_feature_name)
                    self.diff_feature_names.append(abs_diff_feature_name)

        return main_table

    def load(self, filepath):
        params = joblib.load(filepath)
        self.features = params['features']
        self.groupby_feature_names = params['groupby_feature_names']
        return self

    def persist(self, filepath):
        params = {'features': self.features,
                  'groupby_feature_names': self.groupby_feature_names}
        joblib.dump(params, filepath)

    def _create_colname_from_specs(self, groupby_cols, agg, select):
        return '{}_{}_{}'.format('_'.join(groupby_cols), agg, select)


class GroupbyAggregate(BaseTransformer):
    def __init__(self, table_name, id_column, groupby_aggregations, **kwargs):
        super().__init__()
        self.table_name = table_name
        self.id_column = id_column
        self.groupby_aggregations = groupby_aggregations

    def fit(self, table, **kwargs):
        features = pd.DataFrame({self.id_column: table[self.id_column].unique()})

        for groupby_cols, specs in self.groupby_aggregations:
            group_object = table.groupby(groupby_cols)
            for select, agg in specs:
                groupby_aggregate_name = self._create_colname_from_specs(groupby_cols, select, agg)
                features = features.merge(group_object[select]
                                          .agg(agg)
                                          .reset_index()
                                          .rename(index=str,
                                                  columns={select: groupby_aggregate_name})
                                          [groupby_cols + [groupby_aggregate_name]],
                                          on=groupby_cols,
                                          how='left')
        self.features = features
        return self

    def transform(self, table, **kwargs):
        return {'numerical_features': self.features}

    def load(self, filepath):
        self.features = joblib.load(filepath)
        return self

    def persist(self, filepath):
        joblib.dump(self.features, filepath)

    def _create_colname_from_specs(self, groupby_cols, select, agg):
        return '{}_{}_{}_{}'.format(self.table_name, '_'.join(groupby_cols), agg, select)


class BasicHandCraftedFeatures(BaseTransformer):
    def __init__(self, num_workers=1, **kwargs):
        self.num_workers = num_workers
        self.features = None
        self.categorical_features = None
        self.categorical_columns = []

    @property
    def feature_names(self):
        feature_names = list(self.features.columns)
        feature_names.remove('SK_ID_CURR')
        return feature_names

    def transform(self, **kwargs):
        return {'numerical_features': self.features,
                'categorical_features': self.categorical_features,
                'categorical_columns': self.categorical_columns}

    def load(self, filepath):
        self.features, self.categorical_features, self.categorical_columns = joblib.load(filepath)
        return self

    def persist(self, filepath):
        joblib.dump((self.features, self.categorical_features, self.categorical_columns), filepath)


class ApplicationFeatures(BasicHandCraftedFeatures):
    def __init__(self, categorical_columns, numerical_columns, num_workers=1, **kwargs):
        super().__init__(num_workers=num_workers)
        self.categorical_columns = categorical_columns
        self.numerical_columns = numerical_columns
        self.engineered_numerical_columns = ['annuity_income_percentage',
                                             'car_to_birth_ratio',
                                             'car_to_employ_ratio',
                                             'children_ratio',
                                             'credit_to_annuity_ratio',
                                             'credit_to_goods_ratio',
                                             'credit_to_income_ratio',
                                             'days_employed_percentage',
                                             'income_credit_percentage',
                                             'income_per_child',
                                             'income_per_person',
                                             'payment_rate',
                                             'phone_to_birth_ratio',
                                             'phone_to_employ_ratio',
                                             'external_sources_weighted',
                                             'external_sources_min',
                                             'external_sources_max',
                                             'external_sources_sum',
                                             'external_sources_mean',
                                             'external_sources_nanmedian',
                                             'short_employment',
                                             'young_age',
                                             'cnt_non_child',
                                             'child_to_non_child_ratio',
                                             'income_per_non_child',
                                             'credit_per_person',
                                             'credit_per_child',
                                             'credit_per_non_child',
                                             'ext_source_1_plus_2',
                                             'ext_source_1_plus_3',
                                             'ext_source_2_plus_3',
                                             'ext_source_1_is_nan',
                                             'ext_source_2_is_nan',
                                             'ext_source_3_is_nan',
                                             'hour_appr_process_start_radial_x',
                                             'hour_appr_process_start_radial_y',
                                             'id_renewal_days',
                                             'id_renewal_years',
                                             'id_renewal_days_issue',
                                             'id_renewal_years_issue',
                                             'id_renewal_days_delay',
                                             'id_renewal_years_delay'
                                             ]

    def fit(self, application, **kwargs):
        application['annuity_income_percentage'] = application['AMT_ANNUITY'] / application['AMT_INCOME_TOTAL']
        application['car_to_birth_ratio'] = application['OWN_CAR_AGE'] / application['DAYS_BIRTH']
        application['car_to_employ_ratio'] = application['OWN_CAR_AGE'] / application['DAYS_EMPLOYED']
        application['children_ratio'] = application['CNT_CHILDREN'] / application['CNT_FAM_MEMBERS']
        application['credit_to_annuity_ratio'] = application['AMT_CREDIT'] / application['AMT_ANNUITY']
        application['credit_to_goods_ratio'] = application['AMT_CREDIT'] / application['AMT_GOODS_PRICE']
        application['credit_to_income_ratio'] = application['AMT_CREDIT'] / application['AMT_INCOME_TOTAL']
        application['days_employed_percentage'] = application['DAYS_EMPLOYED'] / application['DAYS_BIRTH']
        application['income_credit_percentage'] = application['AMT_INCOME_TOTAL'] / application['AMT_CREDIT']
        application['income_per_child'] = application['AMT_INCOME_TOTAL'] / (1 + application['CNT_CHILDREN'])
        application['income_per_person'] = application['AMT_INCOME_TOTAL'] / application['CNT_FAM_MEMBERS']
        application['payment_rate'] = application['AMT_ANNUITY'] / application['AMT_CREDIT']
        application['phone_to_birth_ratio'] = application['DAYS_LAST_PHONE_CHANGE'] / application['DAYS_BIRTH']
        application['phone_to_employ_ratio'] = application['DAYS_LAST_PHONE_CHANGE'] / application['DAYS_EMPLOYED']
        application['external_sources_weighted'] = np.nansum(
            np.asarray([1.9, 2.1, 2.6]) * application[['EXT_SOURCE_1', 'EXT_SOURCE_2', 'EXT_SOURCE_3']], axis=1)
        application['cnt_non_child'] = application['CNT_FAM_MEMBERS'] - application['CNT_CHILDREN']
        application['child_to_non_child_ratio'] = application['CNT_CHILDREN'] / application['cnt_non_child']
        application['income_per_non_child'] = application['AMT_INCOME_TOTAL'] / application['cnt_non_child']
        application['credit_per_person'] = application['AMT_CREDIT'] / application['CNT_FAM_MEMBERS']
        application['credit_per_child'] = application['AMT_CREDIT'] / (1 + application['CNT_CHILDREN'])
        application['credit_per_non_child'] = application['AMT_CREDIT'] / application['cnt_non_child']
        application['ext_source_1_plus_2'] = np.nansum(application[['EXT_SOURCE_1', 'EXT_SOURCE_2']], axis=1)
        application['ext_source_1_plus_3'] = np.nansum(application[['EXT_SOURCE_1', 'EXT_SOURCE_3']], axis=1)
        application['ext_source_2_plus_3'] = np.nansum(application[['EXT_SOURCE_2', 'EXT_SOURCE_3']], axis=1)
        application['ext_source_1_is_nan'] = np.isnan(application['EXT_SOURCE_1'])
        application['ext_source_2_is_nan'] = np.isnan(application['EXT_SOURCE_2'])
        application['ext_source_3_is_nan'] = np.isnan(application['EXT_SOURCE_3'])
        application['hour_appr_process_start_radial_x'] = application['HOUR_APPR_PROCESS_START'].apply(
            lambda x: cmath.rect(1, 2 * cmath.pi * x / 24).real)
        application['hour_appr_process_start_radial_y'] = application['HOUR_APPR_PROCESS_START'].apply(
            lambda x: cmath.rect(1, 2 * cmath.pi * x / 24).imag)
        application['id_renewal_days'] = application['DAYS_ID_PUBLISH'] - application['DAYS_BIRTH']
        application['id_renewal_years'] = (application['DAYS_ID_PUBLISH'] - application['DAYS_BIRTH']) / 366
        application['id_renewal_days_issue'] = np.vectorize(
            lambda x: max(list(set([min(x, age) for age in [0, 20 * 366, 25 * 366, 45 * 366]]) - set([x]))))(
            application['id_renewal_days'])
        application['id_renewal_years_issue'] = np.vectorize(
            lambda x: max(list(set([min(x, age) for age in [0, 20, 25, 46]]) - set([x]))))(
            application['id_renewal_years'])
        application.loc[application['id_renewal_days_issue'] <= 20 * 366, 'id_renewal_days_delay'] = -1
        application.loc[application['id_renewal_years_issue'] <= 20, 'id_renewal_years_delay'] = -1
        application.loc[application['id_renewal_days_issue'] > 20 * 366, 'id_renewal_days_delay'] = \
            application.loc[application['id_renewal_days_issue'] > 20 * 366, 'id_renewal_days'].values - \
            application.loc[application['id_renewal_days_issue'] > 20 * 366, 'id_renewal_days_issue']
        application.loc[application['id_renewal_years_issue'] > 20, 'id_renewal_years_delay'] = \
            application.loc[application['id_renewal_years_issue'] > 20, 'id_renewal_years'].values - \
            application.loc[application['id_renewal_years_issue'] > 20, 'id_renewal_years_issue']
        for function_name in ['min', 'max', 'sum', 'mean', 'nanmedian']:
            application['external_sources_{}'.format(function_name)] = eval('np.{}'.format(function_name))(
                application[['EXT_SOURCE_1', 'EXT_SOURCE_2', 'EXT_SOURCE_3']], axis=1)

        application['short_employment'] = (application['DAYS_EMPLOYED'] < -2000).astype(int)
        application['young_age'] = (application['DAYS_BIRTH'] < -14000).astype(int)

        self.features = application[['SK_ID_CURR'] + self.engineered_numerical_columns + self.numerical_columns]
        self.categorical_features = application[['SK_ID_CURR'] + self.categorical_columns]
        return self


    @staticmethod
    def last_k_installment_features(gr, periods):
        gr_ = gr.copy()

        features = {}
        for period in periods:
            if period > 10e10:
                period_name = 'all_installment_'
                gr_period = gr_.copy()
            else:
                period_name = 'last_{}_'.format(period)
                gr_period = gr_[gr_['DAYS_INSTALMENT'] > (-1) * period]

            features = add_features_in_group(features, gr_period, 'NUM_INSTALMENT_VERSION',
                                             ['sum', 'mean', 'max', 'min', 'std', 'median', 'iqr'],
                                             period_name)

            features = add_features_in_group(features, gr_period, 'installment_paid_late_in_days',
                                             ['sum', 'mean', 'max', 'min', 'std', 'median', 'kurt', 'iqr'],
                                             period_name)
            features = add_features_in_group(features, gr_period, 'installment_paid_late',
                                             ['count', 'mean'],
                                             period_name)
            features = add_features_in_group(features, gr_period, 'installment_paid_over_amount',
                                             ['sum', 'mean', 'max', 'min', 'std', 'median', 'kurt'],
                                             period_name)
            features = add_features_in_group(features, gr_period, 'installment_paid_over',
                                             ['count', 'mean'],
                                             period_name)
        return features

    @staticmethod
    def trend_in_last_k_installment_features(gr, periods):
        gr_ = gr.copy()
        gr_.sort_values(['DAYS_INSTALMENT'], ascending=False, inplace=True)

        features = {}
        for period in periods:
            gr_period = gr_[gr_['DAYS_INSTALMENT'] > (-1) * period]

            features = add_trend_feature(features, gr_period,
                                         'installment_paid_late_in_days', '{}_period_trend_'.format(period)
                                         )
            features = add_trend_feature(features, gr_period,
                                         'installment_paid_over_amount', '{}_period_trend_'.format(period)
                                         )
        return features

    @staticmethod
    def last_loan_features(gr):
        gr_ = gr.copy()
        last_installments_ids = gr_[gr_['DAYS_INSTALMENT'] == gr_['DAYS_INSTALMENT'].max()]['SK_ID_PREV']
        gr_ = gr_[gr_['SK_ID_PREV'].isin(last_installments_ids)]

        features = {}
        features = add_features_in_group(features, gr_,
                                         'installment_paid_late_in_days',
                                         ['sum', 'mean', 'max', 'min', 'std'],
                                         'last_loan_')
        features = add_features_in_group(features, gr_,
                                         'installment_paid_late',
                                         ['count', 'mean'],
                                         'last_loan_')
        features = add_features_in_group(features, gr_,
                                         'installment_paid_over_amount',
                                         ['sum', 'mean', 'max', 'min', 'std'],
                                         'last_loan_')
        features = add_features_in_group(features, gr_,
                                         'installment_paid_over',
                                         ['count', 'mean'],
                                         'last_loan_')
        return features


def add_features_in_group(features, gr_, feature_name, aggs, prefix):
    for agg in aggs:
        if agg == 'sum':
            features['{}{}_sum'.format(prefix, feature_name)] = gr_[feature_name].sum()
        elif agg == 'mean':
            features['{}{}_mean'.format(prefix, feature_name)] = gr_[feature_name].mean()
        elif agg == 'max':
            features['{}{}_max'.format(prefix, feature_name)] = gr_[feature_name].max()
        elif agg == 'min':
            features['{}{}_min'.format(prefix, feature_name)] = gr_[feature_name].min()
        elif agg == 'std':
            features['{}{}_std'.format(prefix, feature_name)] = gr_[feature_name].std()
        elif agg == 'count':
            features['{}{}_count'.format(prefix, feature_name)] = gr_[feature_name].count()
        elif agg == 'skew':
            features['{}{}_skew'.format(prefix, feature_name)] = skew(gr_[feature_name])
        elif agg == 'kurt':
            features['{}{}_kurt'.format(prefix, feature_name)] = kurtosis(gr_[feature_name])
        elif agg == 'iqr':
            features['{}{}_iqr'.format(prefix, feature_name)] = iqr(gr_[feature_name])
        elif agg == 'median':
            features['{}{}_median'.format(prefix, feature_name)] = gr_[feature_name].median()

    return features


def add_trend_feature(features, gr, feature_name, prefix):
    y = gr[feature_name].values
    try:
        x = np.arange(0, len(y)).reshape(-1, 1)
        lr = LinearRegression()
        lr.fit(x, y)
        trend = lr.coef_[0]
    except:
        trend = np.nan
    features['{}{}'.format(prefix, feature_name)] = trend
    return features


def add_last_k_features_fractions(features, id, period_fractions):
    fraction_features = features[[id]].copy()

    for short_period, long_period in period_fractions:
        short_feature_names = get_feature_names_by_period(features, short_period)
        long_feature_names = get_feature_names_by_period(features, long_period)

        for short_feature, long_feature in zip(short_feature_names, long_feature_names):
            old_name_chunk = '_{}_'.format(short_period)
            new_name_chunk = '_{}by{}_fraction_'.format(short_period, long_period)
            fraction_feature_name = short_feature.replace(old_name_chunk, new_name_chunk)
            fraction_features[fraction_feature_name] = features[short_feature] / features[long_feature]
    return fraction_features


def get_feature_names_by_period(features, period):
    return sorted([feat for feat in features.keys() if '_{}_'.format(period) in feat])


def _divide_features(features, categorical_columns, id_column):
    numerical_columns = [column for column in features.columns if column not in categorical_columns]
    return features[numerical_columns], features[[id_column] + categorical_columns]
