import numpy as np
from steppy.base import BaseTransformer
from steppy.utils import get_logger
from . import pipeline_config as cfg

logger = get_logger()


class ApplicationCleaning(BaseTransformer):
    def __init__(self, fill_missing=False, fill_value=0, **kwargs):
        super().__init__()
        self.fill_missing = fill_missing
        self.fill_value = fill_value

    def transform(self, application):
        application['CODE_GENDER'].replace('XNA', np.nan, inplace=True)
        application['DAYS_EMPLOYED'].replace(365243, np.nan, inplace=True)
        application['DAYS_LAST_PHONE_CHANGE'].replace(0, np.nan, inplace=True)
        application['NAME_FAMILY_STATUS'].replace('Unknown', np.nan, inplace=True)
        application['ORGANIZATION_TYPE'].replace('XNA', np.nan, inplace=True)
        application[cfg.CATEGORICAL_COLUMNS].fillna(-1, inplace=True)

        if self.fill_missing:
            application.fillna(self.fill_value, inplace=True)

        return {'application': application}


