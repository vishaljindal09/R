from functools import partial

from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import BernoulliNB
from sklearn.svm import SVC

from . import pipeline_blocks as blocks


def light_gbm(config, train_mode, suffix=''):
    if train_mode:
        persist_output = True
        cache_output = True
        load_persisted_output = True
    else:
        persist_output = False
        cache_output = True
        load_persisted_output = False

    features = blocks.feature_extraction(config,
                                         train_mode,
                                         suffix,
                                         persist_output=persist_output,
                                         cache_output=cache_output,
                                         load_persisted_output=load_persisted_output
                                         )
    light_gbm = blocks.classifier_light_gbm(features,
                                            config,
                                            train_mode, suffix)

    return light_gbm



def sklearn_pipeline(config, ClassifierClass, clf_name, train_mode, suffix='', normalize=False):
    if train_mode:
        persist_output = True
        cache_output = True
        load_persisted_output = True
    else:
        persist_output = False
        cache_output = True
        load_persisted_output = False

    features = blocks.feature_extraction(config,
                                         train_mode,
                                         suffix,
                                         persist_output=persist_output,
                                         cache_output=cache_output,
                                         load_persisted_output=load_persisted_output)

    sklearn_features = blocks.sklearn_preprocessing(features,
                                                    config,
                                                    train_mode,
                                                    suffix,
                                                    normalize,
                                                    persist_output=persist_output,
                                                    cache_output=cache_output,
                                                    load_persisted_output=load_persisted_output)

    sklearn_clf = blocks.classifier_sklearn(sklearn_features,
                                            ClassifierClass,
                                            config,
                                            clf_name,
                                            train_mode,
                                            suffix)
    return sklearn_clf


def light_gbm_stacking(config, train_mode, suffix='', use_features=False):
    features_oof_preds = blocks.oof_predictions(config, train_mode, suffix,
                                                persist_output=False,
                                                cache_output=False,
                                                load_persisted_output=False)
    if use_features:
        features_engineered = blocks.feature_extraction(config, train_mode, suffix,
                                                        persist_output=False,
                                                        cache_output=False,
                                                        load_persisted_output=False)
        features = blocks.concat_features([features_oof_preds, features_engineered], config, train_mode, suffix,
                                          persist_output=False,
                                          cache_output=False,
                                          load_persisted_output=False)
    else:
        features = features_oof_preds

    light_gbm = blocks.classifier_light_gbm(features, config, train_mode, suffix)

    return light_gbm


def sklearn_pipeline_stacking(config, ClassifierClass, clf_name, train_mode, suffix=''):
    features = blocks.oof_predictions(config, train_mode, suffix,
                                      persist_output=False,
                                      cache_output=False,
                                      load_persisted_output=False)

    normalized_features = blocks.stacking_normalization(features, config, train_mode, suffix,
                                                        persist_output=False,
                                                        cache_output=False,
                                                        load_persisted_output=False
                                                        )
    log_reg = blocks.classifier_sklearn(normalized_features,
                                        ClassifierClass,
                                        config,
                                        clf_name,
                                        train_mode,
                                        suffix)
    return log_reg


PIPELINES = {'lightGBM': light_gbm,
             'lightGBM_stacking_with_features': partial(light_gbm_stacking,
                                                        use_features=True),
             'lightGBM_stacking': partial(light_gbm_stacking,
                                          use_features=False),
             }
